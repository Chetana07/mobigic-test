package com.mobigic.controller;

import org.apache.tomcat.websocket.AuthenticationException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.mobigic.entity.User;
import com.mobigic.service.UserService;

@CrossOrigin("*")
@RestController
@RequestMapping("/user")
public class UserController
{
	@Autowired
	UserService uService;
	
	@PostMapping("/register")
	public User registerUser(@RequestBody User user) throws Exception {
		return uService.registerUser(user);
	}

	
	
	@PostMapping("/loginuser")
	public ResponseEntity loginUser(@RequestBody User user) throws AuthenticationException {
		User foundUser = uService.loginUser(user);
		if(foundUser!=null)
			return new ResponseEntity<>(foundUser, HttpStatus.OK);
		return new ResponseEntity<>("Wrong Username and Password", HttpStatus.FORBIDDEN);
	}
	
}


