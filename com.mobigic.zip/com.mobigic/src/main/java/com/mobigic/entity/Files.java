package com.mobigic.entity;

import javax.persistence.*;


public class Files {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int p_id;
	
	@ManyToOne(cascade = CascadeType.ALL)
	@JoinColumn(name = "u_name")
	private String iname;
	
	private String iUrl;
	
	
	public Files( String iname, String iUrl) {
		super();
		this.iname = iname;
		this.iUrl = iUrl;
	}


	public int getP_id() {
		return p_id;
	}


	public void setP_id(int p_id) {
		this.p_id = p_id;
	}


	public String getIname() {
		return iname;
	}


	public void setIname(String iname) {
		this.iname = iname;
	}


	public String getiUrl() {
		return iUrl;
	}


	public void setiUrl(String iUrl) {
		this.iUrl = iUrl;
	}

	
	
}

