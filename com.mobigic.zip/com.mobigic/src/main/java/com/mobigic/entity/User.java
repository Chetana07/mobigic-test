package com.mobigic.entity;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;


@Entity
@Table(name = "user_info")
public class User {

	
	@Id
	@GeneratedValue
	private int id;
	private String u_name;
	private String u_email;
	private String u_Password;
	
	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getu_name() {
		return u_name;
	}

	public void setu_name(String u_name) {
		this.u_name = u_name;
	}

	public String getu_email() {
		return u_email;
	}

	public void setu_email(String u_email) {
		this.u_email = u_email;
	}

	public String getu_Password() {
		return u_Password;
	}

	public void setu_Password(String u_Password) {
		this.u_Password = u_Password;
	}

	
}

