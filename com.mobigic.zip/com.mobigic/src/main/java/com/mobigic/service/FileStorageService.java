package com.mobigic.service;

import java.io.IOException;
import java.nio.file.FileAlreadyExistsException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;

import org.apache.tomcat.util.http.fileupload.FileUploadException;
import org.springframework.web.multipart.MultipartFile;

public class FileStorageService {

	private final Path root = Paths.get("uploads");

	public void save(MultipartFile file) throws FileUploadException {
		try {
			Files.copy(file.getInputStream(), this.root.resolve(file.getOriginalFilename()));
		} catch (FileAlreadyExistsException e) {
			throw new FileUploadException("File " + e.getLocalizedMessage() + " already exists...!");
		} catch (IOException e) {
			throw new FileUploadException(e.getLocalizedMessage());
		}
	}
}

