package com.mobigic.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.mobigic.entity.User;
import com.mobigic.repository.UserRepository;

@Service
public class UserService {

	@Autowired
	private UserRepository userrepo; 
	
	public User registerUser(User user) throws Exception {
		User foundUser = userrepo.findUserByEmail(user.getu_email());
		if(foundUser != null){
			throw new Exception("User already exists");
		}
		// TODO Auto-generated method stub
			return userrepo.save(user);
	}
	
	
	
	public User loginUser(User user) {
		// TODO Auto-generated method stub
		
		User user1=userrepo.findByEmail(user.getu_email(),user.getu_Password());
		
		if(user1!=null && user1.getu_email().equals(user.getu_email())&& user1.getu_Password().equals(user.getu_Password()))
			return user1 ;
		else
			return null;
	}
}
